# PRODIGY_WD_03

Created a tic-tac-toe web application, using HTML, CSS, and JavaScript. By implementing functions to handle user clicks, track game state, and check for winning conditions ,created an interactive and engaging tic-tac-toe game. With these technologies and functionalities, users can play against each other, aiming to get three markers in a row to win the game.

![2023-08-13 11-28-56_Trim](https://github.com/Tanmay7586/PRODIGY_WD_03/assets/94454903/6bea00c3-21f7-4366-8132-cf0b957dab66)
